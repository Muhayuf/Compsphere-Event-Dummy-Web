

<?php $__env->startSection('container'); ?>
  <section id="hero">
    <h4>We Really Sorry</h4>
    <h2><?php echo e($title); ?> is COMING SOON</h2>
    <h1>Stay Tune on COMPSPHERE 2023</h1>
    <p>Technology for Better Tomorrow</p>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yusuf\OneDrive\Documents\AAA Kuliah\Semester 2\Server-side Internet Programming\Final Project\final-project-fix\resources\views/events/seminar.blade.php ENDPATH**/ ?>