

<?php $__env->startSection('container'); ?>
<div class="content">
    <h2>Get Ready For This!</h2>
    <h1>OVERVIEW CAPTURE THE FLAG (CTF)</h1>   
    <div class="form">
        <p><b>Capture the Flag (CTF)</b> is a network/information security competition that tests each participant's ability to think structurally and creatively in finding hidden valuable information called flags from various problems divided into several categories namely cryptography, digital forensics, binary exploitation, reverse engineering, web exploitation, and Open Source Intelligence (OSINT).</p>
        <div class="fee">
            <p><b>Registration fee:</b> RP100.000(Early Bird)/RP130.000(Reguler)</p>
        </div>

        <a href="/"><button class="btnCompe">Guide Book</button></a>
        <a href="/"><button class="btnCompe"><b>Register</b></button></a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yusuf\OneDrive\Documents\AAA Kuliah\Semester 2\Server-side Internet Programming\Final Project\final-project-fix\resources\views/competition/ctf.blade.php ENDPATH**/ ?>