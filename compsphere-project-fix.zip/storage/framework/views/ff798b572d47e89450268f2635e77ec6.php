<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdn.lineicons.com/4.0/lineicons.css">
    <link rel="stylesheet" href="css/styles.css">
    <!-- Font Awesome -->
    <script src="https://kit.fontawesome.com/40d012bf96.js" crossorigin="anonymous"></script>
    <title>Document</title>
</head>
<body>
    <script>
        $('#btn').click(function(){
          $('.alert').addClass("show");
          $('.alert').removeClass("hide");
          $('.alert').addClass("showAlert");
          setTimeout(function(){
            $('.alert').removeClass("show");
            $('.alert').addClass("hide");
          },5000);
        });
        $('.close-btn').click(function(){
          $('.alert').removeClass("show");
          $('.alert').addClass("hide");
        });
     </script>
    <div class="alert hide">
        <span class="fas fa-exclamation-circle"></span>
        <?php echo e(session('success')); ?>

        <div class="close-btn">
            <span class="fas fa-times"></span>
        </div>
    </div>

    <button id="btn">asolole</button>

</body>
</html>
<?php /**PATH C:\Users\yusuf\OneDrive\Documents\AAA Kuliah\Semester 2\Server-side Internet Programming\Final Project\final-project-fix\resources\views/login-register/tes.blade.php ENDPATH**/ ?>