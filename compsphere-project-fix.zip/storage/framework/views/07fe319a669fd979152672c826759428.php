

<?php $__env->startSection('container'); ?>
<div class="content">
    <h2>Get Ready For This!</h2>
    <h1>OVERVIEW <?php echo e($overview); ?></h1>   
    <div class="form">
        <p><?php echo e($paragraph); ?></p>
        <div class="fee">
            <p><b>Registration fee:</b> RP80.000(Early Bird)/RP100.000(Reguler)</p>
        </div>

        <a href="/"><button class="btnCompe">Guide Book</button></a>
        <a href="/"><button class="btnCompe"><b>Register</b></button></a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yusuf\OneDrive\Documents\AAA Kuliah\Semester 2\Server-side Internet Programming\Final Project\final-project-fix\resources\views/competition/uiux.blade.php ENDPATH**/ ?>