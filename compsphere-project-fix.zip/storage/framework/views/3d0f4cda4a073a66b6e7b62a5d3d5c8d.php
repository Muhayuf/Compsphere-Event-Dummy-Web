

<?php $__env->startSection('container'); ?>
    <div class="person">
        <div class="photoPerson">
            <img class="realPhoto" src="img/meme.jpg" alt="Not Your Face" width="270">
        </div>
        <div class="textPerson">
            <h4>Hello, Master</h4>
            <h2><?php echo e(auth()->user()->name); ?></h2>
            <h1>We're Happy You Here</h1>
            <p>Let's Join Our Events/Competition</p>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yusuf\OneDrive\Documents\AAA Kuliah\Semester 2\Server-side Internet Programming\Final Project\final-project-fix\resources\views/login-register/dashboard.blade.php ENDPATH**/ ?>