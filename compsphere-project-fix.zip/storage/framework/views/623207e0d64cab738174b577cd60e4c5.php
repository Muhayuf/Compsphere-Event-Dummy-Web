
<link rel="stylesheet" href="css/style.css">

<?php $__env->startSection('container'); ?>
  <section id="hero">
    <h4>We Really Sorry</h4>
    <h2><?php echo e($title); ?> is COMING SOON</h2>
    <h1>Technology for Better Tomorrow</h1>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yusuf\OneDrive\Documents\AAA Kuliah\Semester 2\Server-side Internet Programming\Final Project\final-project-fix\resources\views/seminar.blade.php ENDPATH**/ ?>