

<?php $__env->startSection('container'); ?>
<div class="content">
    <h2>Get Ready For This!</h2>
    <h1>OVERVIEW COMPETITIVE PROGRAMMING</h1>   
    <div class="form">
        <p><b>Competitive Programming</b> is a competition that tests the ability to think logically to solve problems using a computer program written using the C, C++, or Java language within specified time and memory constraints.</p>
        <div class="fee">
            <p><b>Registration fee:</b> RP100.000(Early Bird)/RP130.000(Reguler)</p>
        </div>

        <a href="/"><button class="btnCompe">Guide Book</button></a>
        <a href="/"><button class="btnCompe"><b>Register</b></button></a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yusuf\OneDrive\Documents\AAA Kuliah\Semester 2\Server-side Internet Programming\Final Project\final-project-fix\resources\views/competition/cp.blade.php ENDPATH**/ ?>