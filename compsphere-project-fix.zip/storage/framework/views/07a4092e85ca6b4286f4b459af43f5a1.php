

<?php $__env->startSection('container'); ?>
    <div class="person">
        <div class="photoPerson">
            <img class="realPhoto" src="img/yusuf.jpg" alt="Muhammad Yusuf" width="200">
        </div>
        <div class="textPerson">
            <h4>Hello, I'm The Developer of This Web</h4>
            <h2>Muhammad Yusuf</h2>
            <h1>Undergraduate IT Student at President University</h1>
            <a class="btnPerson" href="https://www.linkedin.com/in/muhammad-yusuf-588280208/">View LinkedIn</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yusuf\OneDrive\Documents\AAA Kuliah\Semester 2\Server-side Internet Programming\Final Project\compspherel-project-fix\resources\views/about.blade.php ENDPATH**/ ?>