

<?php $__env->startSection('container'); ?>
<div class="content">
    <h2>Get Ready For This!</h2>
    <h1>OVERVIEW ENTERPRISING RESOURSE PLANNING (ERP)</h1>   
    <div class="form">
        <p><b>ERP competition</b> is the rivalry among vendors offering software solutions that integrate various business processes into a single system.</p>
        <div class="fee">
            <p><b>Registration fee:</b> RP100.000(Early Bird)/RP130.000(Reguler)</p>
        </div>

        <a href="/"><button class="btnCompe">Guide Book</button></a>
        <a href="/"><button class="btnCompe"><b>Register</b></button></a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yusuf\OneDrive\Documents\AAA Kuliah\Semester 2\Server-side Internet Programming\Final Project\final-project-fix\resources\views/competition/erp.blade.php ENDPATH**/ ?>