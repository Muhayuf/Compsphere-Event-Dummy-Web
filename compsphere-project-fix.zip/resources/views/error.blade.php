@extends('layouts.main')

@section('container')
  <section id="hero">
    <h4>We Really Sorry</h4>
    <h2>This Competition's Guidebook</h2>
    <h1>is Not Finish Yet</h1>
    <p>:( :( :(</p>
  </section>
@endsection