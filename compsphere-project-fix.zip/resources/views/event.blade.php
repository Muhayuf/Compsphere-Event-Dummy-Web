@extends('layouts.main')

@section('container')
  <section id="hero">
    <h4>We Really Sorry</h4>
    <h2>{{ $title }} is COMING SOON</h2>
    <h1>Stay Tune on COMPSPHERE 2023</h1>
    <p>Technology for Better Tomorrow</p>
  </section>
@endsection